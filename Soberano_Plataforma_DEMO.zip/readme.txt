Instruções para publicar a plataforma demo:

1. Vá até https://vercel.com ou https://netlify.com
2. Crie uma conta gratuita com seu e-mail Google ou GitHub
3. Faça upload dos arquivos deste ZIP como um novo projeto
4. Em segundos, você receberá um link (ex: https://soberanodecide.vercel.app)
5. Acesse com:
   - Login: alvaro@pereiraiaccino.com
   - Senha: DemoSoberano2025