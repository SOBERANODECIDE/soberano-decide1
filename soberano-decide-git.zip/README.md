# Plataforma Soberano Decide

Sitio inicial en español, preparado para deploy en Vercel.